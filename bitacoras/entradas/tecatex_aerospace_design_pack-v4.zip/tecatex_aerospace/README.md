# TECATEX Aerospace - El Desafío Cohete de Pólvora (V4)

## 📁 Estructura del Proyecto
- `index.html`: Aplicación web interactiva en estilo Cyber-Tech / Y2K (Monocromático B&W).
- `README.md`: Documentación oficial de la misión y especificaciones del sistema.

---

## 🚀 Resumen de la Misión
- **Proyecto:** Misión de Propulsión Aeroespacial (Proyecto Final 2026).
- **Ventana de Lanzamiento:** Miércoles 2 de diciembre de 2026 a las 7:00 a. m. — Hora local de Culiacán, Sinaloa (UTC−7).
- **Entorno:** Órbita de Sinaloa, México.
- **Entidad:** TECATEX Aerospace Division.

---

## 📄 Contenido y Arquitectura

### 1. Cuenta Regresiva al Lanzamiento (T-Minus)
- Temporizador en tiempo real sincronizado exactamente con el **Miércoles 2 de diciembre de 2026 a las 7:00 a. m. (UTC−7, Culiacán, Sinaloa)** con desglose en Días, Horas, Minutos y Segundos.

### 2. El Desafío Cohete de Pólvora
* **01. Objetivo del Proyecto:** Diseñar, ensamblar y ejecutar el lanzamiento exitoso de una unidad aerodinámica propulsada por combustible sólido de pólvora, demostrando estabilidad, alcance computado y recuperación segura.
* **02. Innovación Sinaloense:** Desarrollado como prototipo de evaluación técnica en 2026, combinando física aplicada, cálculos de trayectoria y el distintivo sello conceptual de Tecatex Aerospace.

### 3. Especificaciones del Vector
* **01 Propulsión Sólida:** Núcleo reactivo de pólvora optimizado para impulso inicial sostenido y máxima aceleración vertical.
* **02 Fuselaje Aerodinámico:** Estructura ligera ultra-resistente diseñada bajo tolerancias mínimas para minimizar el arrastre.
* **03 Aero-Estabilidad:** Aletas estabilizadoras simétricas calibradas para trayectoria parabólica rectilínea.

### 4. Integrantes del Equipo (Ingenieros de Misión)
1. **Hugo Ahumada Cázares**
2. **Andrea Noriega Manjarrez**
3. **Jorge Ernesto Rubio Álvarez**
4. **Daniel Eduardo Gamez Ibarra**
5. **María Isabella Domínguez Lizárraga**

---

## 💡 Instrucciones de Uso
1. Descomprime la carpeta `tecatex_aerospace/`.
2. Abre el archivo `index.html` directamente en cualquier navegador moderno (Chrome, Firefox, Safari o Edge).
